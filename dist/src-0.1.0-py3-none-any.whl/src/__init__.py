from src.configs.config_logger import configure_logging

configure_logging()
