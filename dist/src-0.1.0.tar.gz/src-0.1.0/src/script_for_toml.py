def start():
    print("Hello")